package cat.yoink.yoinkhack.impl.module.hud;

import cat.yoink.yoinkhack.api.module.Category;
import cat.yoink.yoinkhack.api.module.Module;

/**
 * @author yoink
 * @since 8/26/2020
 */
public class BPS extends Module
{
	public BPS(String name, Category category, String description)
	{
		super(name, category, description);
	}
}
