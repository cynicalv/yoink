package cat.yoink.yoinkhack.mixin.mixins.accessor;

/**
 * @author yoink
 * @since 8/26/2020
 */
public interface ITimer
{
	float getTickLength();

	void setTickLength(float length);
}
