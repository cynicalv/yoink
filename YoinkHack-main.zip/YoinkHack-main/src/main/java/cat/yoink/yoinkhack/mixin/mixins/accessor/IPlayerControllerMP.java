package cat.yoink.yoinkhack.mixin.mixins.accessor;

/**
 * @author yoink
 * @since 8/28/2020
 */
public interface IPlayerControllerMP
{
	boolean isHittingBlock();
}
