package cat.yoink.yoinkhack.impl.module.render;

import cat.yoink.yoinkhack.api.module.Category;
import cat.yoink.yoinkhack.api.module.Module;

/**
 * @author yoink
 * @since 8/26/2020
 */
public class ShulkerViewer extends Module
{
	public ShulkerViewer(String name, Category category, String description)
	{
		super(name, category, description);
	}
}
