package cat.yoink.yoinkhack.mixin.mixins.accessor;

import net.minecraft.util.Timer;

/**
 * @author yoink
 * @since 8/28/2020
 */
public interface IMinecraft
{
	Timer getTimer();
}
