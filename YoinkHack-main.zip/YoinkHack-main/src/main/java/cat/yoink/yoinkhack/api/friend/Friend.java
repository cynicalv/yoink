package cat.yoink.yoinkhack.api.friend;

/**
 * @author yoink
 * @since 8/28/2020
 */
public class Friend
{
	private final String name;

	public Friend(String name)
	{
		this.name = name;
	}

	public String getName()
	{
		return name;
	}
}
