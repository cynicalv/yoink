package cat.yoink.yoinkhack.mixin.mixins.accessor;

/**
 * @author yoink
 * @since 8/28/2020
 */
public interface ISPacketPlayerPosLook
{
	float getYaw();

	void setYaw(float yaw);

	float getPitch();

	void setPitch(float pitch);
}
