package cat.yoink.yoinkhack.impl.event;

import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

/**
 * @author yoink
 * @since 8/28/2020
 */
@Cancelable
public class WalkEvent extends Event
{
}
