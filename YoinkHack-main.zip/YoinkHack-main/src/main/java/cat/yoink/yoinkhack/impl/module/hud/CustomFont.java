package cat.yoink.yoinkhack.impl.module.hud;

import cat.yoink.yoinkhack.api.module.Category;
import cat.yoink.yoinkhack.api.module.Module;

/**
 * @author yoink
 * @since 8/31/2020
 */
public class CustomFont extends Module
{
	public CustomFont(String name, Category category, String description)
	{
		super(name, category, description);
	}
}
